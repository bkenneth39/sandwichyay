<!-- Bootstrap core JavaScript-->
<script src="login-css/vendor/jquery/jquery.min.js"></script>
<script src="login-css/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- Core plugin JavaScript-->
<script src="login-css/vendor/jquery-easing/jquery.easing.min.js"></script>

<!-- Custom scripts for all pages-->
<script src="login-css/js/sb-admin-2.min.js"></script>

</body>

</html>