<?php
include 'templates/admin_header.php';

?>

<!-- Begin Page Content -->
<div class="container-fluid">
    <div class="card shadow mb-4">
        <div class="alert clearfix">
            <a type="button" class="btn btn-success btn-lg" href="add.php">
                &#x2b; Menu
            </a>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th> # </th>
                            <th> Gambar </th>
                            <th> Nama </th>
                            <th> Harga </th>
                            <th> Kategori </th>
                            <th> Deskripsi </th>
                            <th> Action </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        require_once "../koneksi.php";
                        $index = 1;
                        $query = "SELECT * FROM menu";
                        $result = $conn->query($query);
                        while ($line = $result->fetch_assoc()) {
                        ?>
                            <tr>
                                <td><?= $index ?></td>
                                <td><img src='img/<?= $line['Gambar'] ?>'></td>
                                <td><?= $line['NamaMenu'] ?></td>
                                <td><?= $line['Harga'] ?></td>
                                <td><?= $line['Kategori'] ?></td>
                                <td><?= $line['Deskripsi'] ?></td>
                                <td>
                                    <a href="edit.php?id=<?= $line['ID'] ?>" class="btn btn-warning btn-circle btn-sm" role="button">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <a href="delete.php?id=<?= $line['ID'] ?>" class="btn btn-danger btn-circle btn-sm" role="button">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php
                            $index++;
                        }
                        mysqli_free_result($result);
                        mysqli_close($conn);
                        ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <th> # </th>
                            <th> Gambar </th>
                            <th> Nama </th>
                            <th> Harga </th>
                            <th> Kategori </th>
                            <th> Deskripsi </th>
                            <th> Action </th>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
    <!-- Page Heading -->
</div>
<!-- /.container-fluid -->

<?php
include 'templates/admin_footer.php';
?>