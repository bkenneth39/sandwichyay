<?php
include 'templates/admin_header.php';

?>

<!-- Begin Page Content -->
<div class="container-fluid">
    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th> # </th>
                            <th> ID </th>
                            <th> Name </th>
                            <th> Email </th>
                            <th> Birthdate </th>
                            <th> Gender </th>
                            <th> Action </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        require_once "../koneksi.php";
                        $index = 1;
                        $query = "SELECT * FROM user WHERE Role = 1";
                        $result = $conn->query($query);
                        while ($line = $result->fetch_assoc()) {
                        ?>
                            <tr>
                                <td><?= $index ?></td>
                                <td><?= $line['ID'] ?></td>
                                <td><?= $line['FirstName'] . " " . $line['LastName'] ?></td>
                                <td><?= $line['Email'] ?></td>
                                <td><?= $line['BirthDate'] ?></td>
                                <td><?= $line['Gender'] ?></td>
                                <td>
                                    <a href="delete-user.php?id=<?= $line['ID'] ?>" class="btn btn-danger btn-circle" role="button">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php
                            $index++;
                        }
                        mysqli_free_result($result);
                        mysqli_close($conn);
                        ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <th> # </th>
                            <th> ID </th>
                            <th> Name </th>
                            <th> Email </th>
                            <th> Birthdate </th>
                            <th> Gender </th>
                            <th> Action </th>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
    <!-- Page Heading -->
</div>
<!-- /.container-fluid -->

<?php
include 'templates/admin_footer.php';
?>