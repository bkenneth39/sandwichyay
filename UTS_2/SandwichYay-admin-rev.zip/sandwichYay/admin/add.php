<?php
include 'templates/admin_header.php';
require '../koneksi.php';
require 'function.php';
if (isset($_POST["submit"])) {
    if (add($_POST) > 0) {
        echo "
				<script>
					document.location.href = 'admin.php';
				</script>
			";
    } else {
        echo "
				<script>
					document.location.href = 'admin.php';
				</script>
			";
    }
}

?>



<!-- Begin Page Content -->
<div class="container-fluid">
    <div class="card shadow mb-4">
        <form class="p-3" method="post" action="" enctype="multipart/form-data">
            <div class="mb-3">
                <label for="NamaMenu">Nama Menu</label>
                <input type="text" class="form-control" id="NamaMenu" name="NamaMenu" maxlength="30" placeholder="Nama Menu" required>
            </div>
            <div class="mb-3">
                <label for="Harga">Harga</label>
                <input type="number" class="form-control" id="Harga" name="Harga" maxlength="20" placeholder="Harga" required>
            </div>
            <div class="mb-3">
                <label for="Kategori">Kategori</label>
                <select name="Kategori" id="Kategori" class="form-control" required>
                    <option value="">Pilih Kategori</option>
                    <option value="Breakfast">Breakfast</option>
                    <option value="Entrees">Entrees</option>
                    <option value="Salads">Salads</option>
                    <option value="Sides">Sides</option>
                    <option value="Kid's Meals">Kid's Meals</option>
                    <option value="Treats">Treats</option>
                    <option value="Drinks">Drinks</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="Deskripsi">Deskripsi</label>
                <input type="text" class="form-control" id="Deskripsi" name="Deskripsi" maxlength="100" placeholder="Deskripsi" required>
            </div>
            <div class="mb-3">
                <label for="Gambar">Gambar</label>
                <input type="file" class="form-control-file" id="Gambar" name="Gambar" accept="image/jpeg">
            </div>
            <button type="submit" name="submit" class="btn btn-primary"> Simpan </button>
            <a href="admin.php" class="btn btn-default">Cancel</a>
        </form>
    </div>
    <!-- Page Heading -->
</div>
<!-- /.container-fluid -->

<?php
include 'templates/admin_footer.php';
?>