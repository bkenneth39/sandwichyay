<?php
include 'templates/admin_header.php';
require 'function.php';

$id = $_GET["id"];

$menu = query("SELECT * FROM menu WHERE ID = $id")[0];

if (isset($_POST["submit"])) {
    if (edit($_POST) > 0) {
        echo "
				<script>
					document.location.href = 'admin.php';
				</script>
			";
    } else {
        echo "
				<script>
					document.location.href = 'admin.php';
				</script>
			";
    }
}

?>

<!-- Begin Page Content -->
<div class="container-fluid">
    <div class="card shadow mb-4">
        <form class="p-3" method="post" action="" enctype="multipart/form-data">
            <input type="hidden" name="id" value="<?= $menu["ID"]; ?>">
            <input type="hidden" name="gambarLama" value="<?= $menu["Gambar"]; ?>">
            <div class="mb-3">
                <label for="NamaMenu">Nama Menu</label>
                <input type="text" class="form-control" id="NamaMenu" name="NamaMenu" maxlength="30" placeholder="Nama Menu" required value="<?= $menu["NamaMenu"]; ?>">
            </div>
            <div class="mb-3">
                <label for="Harga">Harga</label>
                <input type="number" class="form-control" id="Harga" name="Harga" maxlength="20" placeholder="Harga" required value="<?= $menu["Harga"]; ?>">
            </div>
            <div class="mb-3">
                <label for="Kategori">Kategori</label>
                <select name="Kategori" id="Kategori" class="form-control">
                    <option value="">Pilih Kategori</option>
                    <option value="Breakfast">Breakfast</option>
                    <option value="Entrees">Entrees</option>
                    <option value="Salads">Salads</option>
                    <option value="Sides">Sides</option>
                    <option value="Kid's Meals">Kid's Meals</option>
                    <option value="Treats">Treats</option>
                    <option value="Drinks">Drinks</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="Deskripsi">Deskripsi</label>
                <input type="text" class="form-control" id="Deskripsi" name="Deskripsi" maxlength="100" placeholder="Deskripsi" required value="<?= $menu["Deskripsi"]; ?>">
            </div>
            <div class="mb-3">
                <label for="Gambar">Gambar</label> <br>
                <img src="img/<?= $menu["Gambar"]; ?>">
                <input type="file" class="form-control-file" id="Gambar" name="Gambar" accept="image/jpeg">
            </div>
            <button type="submit" name="submit" class="btn btn-primary"> Edit </button>
            <a href="admin.php" class="btn btn-default">Cancel</a>
        </form>
    </div>
    <!-- Page Heading -->
</div>
<!-- /.container-fluid -->

<?php
include 'templates/admin_footer.php';
?>